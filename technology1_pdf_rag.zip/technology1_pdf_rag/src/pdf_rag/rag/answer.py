from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Set

from ..utils import simple_tokenize
from .bm25 import Retrieved


STOPWORDS = {
    "the","a","an","and","or","to","of","in","on","for","with","as","at","by","from","is","are","was","were",
    "be","been","it","this","that","these","those","we","they","their","our","you","your","i","he","she","them",
    "not","but","if","then","than","into","about","over","under","up","down","between","during","also","can",
}


def _sentences(text: str) -> list[str]:
    # Simple sentence splitter
    parts = re.split(r"(?<=[.!?])\s+", text)
    return [p.strip() for p in parts if p.strip()]


def _score_sentence(sentence: str, q_terms: set[str]) -> int:
    s_terms = set(simple_tokenize(sentence))
    return len(s_terms & q_terms)


def build_answer(question: str, retrieved: list[Retrieved], max_sentences: int = 4) -> tuple[str, list[dict]]:
    if not retrieved:
        return "I couldn't find relevant information in the indexed PDFs.", []

    q_terms = {t for t in simple_tokenize(question) if t not in STOPWORDS and len(t) > 2}

    # Candidate sentences from top chunks
    scored: list[tuple[int, str, Retrieved]] = []
    for r in retrieved[:10]:
        for sent in _sentences(r.chunk.text):
            sc = _score_sentence(sent, q_terms)
            if sc > 0:
                scored.append((sc, sent, r))

    scored.sort(key=lambda x: (x[0], x[2].score), reverse=True)

    chosen_sents: list[str] = []
    used: set[str] = set()
    for sc, sent, r in scored:
        key = sent.lower()
        if key in used:
            continue
        used.add(key)
        chosen_sents.append(sent)
        if len(chosen_sents) >= max_sentences:
            break

    if not chosen_sents:
        # Fallback: use first part of best chunk
        chosen_sents = [_sentences(retrieved[0].chunk.text)[0] if _sentences(retrieved[0].chunk.text) else retrieved[0].chunk.text[:240]]

    answer = " ".join(chosen_sents).strip()

    # Build citations: ensure at least 2 distinct {pdf,page} if available
    sources: list[dict] = []
    seen_pairs: set[tuple[str,int]] = set()
    for r in retrieved:
        pair = (r.chunk.pdf, r.chunk.page)
        if pair in seen_pairs:
            continue
        seen_pairs.add(pair)
        snippet = r.chunk.text[:240].strip()
        sources.append({"pdf": r.chunk.pdf, "page": r.chunk.page, "snippet": snippet})
        if len(sources) >= 4:
            break

    return answer, sources
