from __future__ import annotations

import argparse
from pathlib import Path

from ..config import default_paths
from .ingest import build_index, save_index, load_index
from .bm25 import BM25Index
from .answer import build_answer


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Ask questions over downloaded PDFs (BM25 RAG).")
    p.add_argument("--question", "-q", required=True, help="Question to ask.")
    p.add_argument("--top-k", type=int, default=6, help="How many chunks to retrieve.")
    p.add_argument("--pdf-dir", default=None, help="PDF folder (default: data/pdfs).")
    p.add_argument("--reindex", action="store_true", help="Rebuild index before answering.")
    p.add_argument("--chunk-size", type=int, default=800)
    p.add_argument("--overlap", type=int, default=200)
    return p


def main() -> int:
    args = build_parser().parse_args()
    paths = default_paths()
    pdf_dir = Path(args.pdf_dir) if args.pdf_dir else paths.pdf_dir

    if args.reindex:
        index = build_index(pdf_dir=pdf_dir, chunk_size=args.chunk_size, overlap=args.overlap)
        save_index(index, paths.index_dir)
    else:
        index = load_index(paths.index_dir)

    bm25 = BM25Index(index)
    retrieved = bm25.retrieve(args.question, top_k=args.top_k)
    answer, sources = build_answer(args.question, retrieved)

    print("\nAnswer:\n" + answer)
    print("\nSources:")
    for s in sources:
        print(f" - {s['pdf']} (p.{s['page']}): {s['snippet'][:120]}...")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
