from __future__ import annotations

import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List

from pypdf import PdfReader  # pypdf is the maintained fork of PyPDF2

from ..utils import ensure_dir, simple_tokenize


@dataclass
class Chunk:
    text: str
    pdf: str
    page: int
    chunk_id: str  # stable identifier (pdf|page|offset)


@dataclass
class IndexData:
    chunks: list[Chunk]
    tokenized_corpus: list[list[str]]


def extract_pages(pdf_path: Path) -> list[tuple[int, str]]:
    reader = PdfReader(str(pdf_path))
    pages: list[tuple[int, str]] = []
    for i, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        text = " ".join(text.split())
        if text.strip():
            pages.append((i, text))
    return pages


def chunk_text(text: str, chunk_size: int = 800, overlap: int = 200) -> list[str]:
    if chunk_size <= 0:
        return [text]
    if overlap >= chunk_size:
        overlap = max(0, chunk_size // 4)

    chunks: list[str] = []
    start = 0
    n = len(text)
    while start < n:
        end = min(n, start + chunk_size)
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - overlap
        if start < 0:
            start = 0
        if end == n:
            break
    return chunks


def build_index(pdf_dir: Path, chunk_size: int = 800, overlap: int = 200) -> IndexData:
    chunks: list[Chunk] = []
    tokenized: list[list[str]] = []

    pdf_files = sorted([p for p in pdf_dir.glob("*.pdf") if p.is_file()])
    for pdf_path in pdf_files:
        pdf_name = pdf_path.name
        for page_no, page_text in extract_pages(pdf_path):
            for j, ctext in enumerate(chunk_text(page_text, chunk_size=chunk_size, overlap=overlap)):
                chunk_id = f"{pdf_name}|{page_no}|{j}"
                chunks.append(Chunk(text=ctext, pdf=pdf_name, page=page_no, chunk_id=chunk_id))
                tokenized.append(simple_tokenize(ctext))

    return IndexData(chunks=chunks, tokenized_corpus=tokenized)


def save_index(index: IndexData, index_dir: Path) -> None:
    ensure_dir(index_dir)
    with (index_dir / "chunks.pkl").open("wb") as f:
        pickle.dump(index.chunks, f)
    with (index_dir / "tokenized_corpus.pkl").open("wb") as f:
        pickle.dump(index.tokenized_corpus, f)


def load_index(index_dir: Path) -> IndexData:
    with (index_dir / "chunks.pkl").open("rb") as f:
        chunks = pickle.load(f)
    with (index_dir / "tokenized_corpus.pkl").open("rb") as f:
        tokenized = pickle.load(f)
    return IndexData(chunks=chunks, tokenized_corpus=tokenized)
