from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

from rank_bm25 import BM25Okapi

from ..utils import simple_tokenize
from .ingest import Chunk, IndexData


@dataclass
class Retrieved:
    chunk: Chunk
    score: float


class BM25Index:
    def __init__(self, index_data: IndexData):
        self.index_data = index_data
        self._bm25 = BM25Okapi(index_data.tokenized_corpus)

    def retrieve(self, query: str, top_k: int = 5) -> list[Retrieved]:
        q = simple_tokenize(query)
        scores = self._bm25.get_scores(q)
        # pick top_k indices
        ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[: max(1, top_k)]
        out: list[Retrieved] = []
        for i in ranked:
            out.append(Retrieved(chunk=self.index_data.chunks[i], score=float(scores[i])))
        return out
