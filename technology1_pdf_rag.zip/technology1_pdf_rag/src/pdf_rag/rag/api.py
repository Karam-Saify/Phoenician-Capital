from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from ..config import default_paths
from .ingest import build_index, save_index, load_index
from .bm25 import BM25Index
from .answer import build_answer

logger = logging.getLogger(__name__)

app = FastAPI(title="PDF RAG Chatbot", version="1.0")

_paths = default_paths()
_bm25: Optional[BM25Index] = None


class IngestRequest(BaseModel):
    pdf_dir: Optional[str] = Field(default=None, description="Folder containing PDFs (default: data/pdfs)")
    chunk_size: int = 800
    overlap: int = 200


class IngestResponse(BaseModel):
    pdfs_read: int
    chunks_indexed: int
    index_dir: str


class ChatRequest(BaseModel):
    question: str
    top_k: int = 6


class ChatResponse(BaseModel):
    answer: str
    sources: list[dict]


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "index_loaded": _bm25 is not None}


@app.post("/ingest", response_model=IngestResponse)
def ingest(req: IngestRequest) -> IngestResponse:
    global _bm25
    pdf_dir = Path(req.pdf_dir) if req.pdf_dir else _paths.pdf_dir
    if not pdf_dir.exists():
        raise HTTPException(status_code=400, detail=f"PDF directory not found: {pdf_dir}")

    index = build_index(pdf_dir=pdf_dir, chunk_size=req.chunk_size, overlap=req.overlap)
    save_index(index, _paths.index_dir)
    _bm25 = BM25Index(index)

    pdfs_read = len(list(pdf_dir.glob("*.pdf")))
    return IngestResponse(pdfs_read=pdfs_read, chunks_indexed=len(index.chunks), index_dir=str(_paths.index_dir))


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    global _bm25
    if _bm25 is None:
        # Try lazy load
        try:
            index = load_index(_paths.index_dir)
            _bm25 = BM25Index(index)
        except Exception:
            raise HTTPException(status_code=400, detail="Index not found. Run POST /ingest first.")

    retrieved = _bm25.retrieve(req.question, top_k=req.top_k)
    answer, sources = build_answer(req.question, retrieved)
    # Hard requirement: at least 2 citations if we have enough material
    if len(sources) < 2 and retrieved:
        # Add more from retrieval list
        for r in retrieved:
            src = {"pdf": r.chunk.pdf, "page": r.chunk.page, "snippet": r.chunk.text[:240].strip()}
            if src not in sources:
                sources.append(src)
            if len(sources) >= 2:
                break

    return ChatResponse(answer=answer, sources=sources)
