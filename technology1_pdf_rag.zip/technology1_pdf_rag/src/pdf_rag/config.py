from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Paths:
    project_root: Path
    data_dir: Path
    pdf_dir: Path
    index_dir: Path


def default_paths() -> Paths:
    project_root = Path(__file__).resolve().parents[2]
    data_dir = project_root / "data"
    return Paths(
        project_root=project_root,
        data_dir=data_dir,
        pdf_dir=data_dir / "pdfs",
        index_dir=data_dir / "index",
    )
