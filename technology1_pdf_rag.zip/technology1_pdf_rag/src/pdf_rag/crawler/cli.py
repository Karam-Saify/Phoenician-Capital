from __future__ import annotations

import argparse
import logging
from collections import Counter
from pathlib import Path

from ..config import default_paths
from .crawler import crawl
from .download import download_all, write_manifest


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Crawl a website for PDF links and download PDFs.")
    p.add_argument("--start-url", required=True, help="Seed URL to start crawling from.")
    p.add_argument("--max-depth", type=int, default=2, help="Maximum crawl depth from the start URL.")
    p.add_argument("--max-pdfs", type=int, default=50, help="Maximum number of PDFs to download.")
    p.add_argument("--max-pages", type=int, default=500, help="Safety limit for number of HTML pages to visit.")
    p.add_argument("--out", default=None, help="Output directory for PDFs (default: data/pdfs).")
    p.add_argument("--manifest", default=None, help="Path to manifest.json (default: data/manifest.json).")
    p.add_argument("--rate-limit", type=float, default=0.2, help="Delay (seconds) between requests.")
    p.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return p


def main() -> int:
    args = build_parser().parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level))

    paths = default_paths()
    pdf_dir = Path(args.out) if args.out else paths.pdf_dir
    manifest_path = Path(args.manifest) if args.manifest else (paths.data_dir / "manifest.json")

    result = crawl(
        start_url=args.start_url,
        max_depth=args.max_depth,
        max_pages=args.max_pages,
        rate_limit_s=args.rate_limit,
    )

    records = download_all(
        pdf_candidates=result.pdf_candidates,
        out_dir=pdf_dir,
        max_pdfs=args.max_pdfs,
        rate_limit_s=args.rate_limit,
    )

    manifest = write_manifest(
        manifest_path=manifest_path,
        start_url=result.start_url,
        max_depth=args.max_depth,
        max_pdfs=args.max_pdfs,
        pages_visited=result.pages_visited,
        pdfs_found=len(result.pdf_candidates),
        records=records,
        crawl_failures=result.crawl_failures,
    )

    download_failures = [r for r in records if r.status == "failed"]
    crawl_fail_counts = Counter((x.get("reason", "unknown") for x in result.crawl_failures))
    dl_fail_counts = Counter(((r.reason or "unknown") for r in download_failures))

    print("\n=== End-of-Run Summary ===")
    print(f"Pages visited:     {result.pages_visited}")
    print(f"PDFs found:        {len(result.pdf_candidates)}")
    print(f"PDFs downloaded:   {manifest['run']['pdfs_downloaded']}")
    print(f"Failures:          {manifest['run']['crawl_failures'] + manifest['run']['download_failures']}")

    if result.crawl_failures:
        print("Crawl failures (top reasons):")
        for reason, cnt in crawl_fail_counts.most_common(5):
            print(f"  - {cnt}x {reason}")

    if download_failures:
        print("Download failures (top reasons):")
        for reason, cnt in dl_fail_counts.most_common(5):
            print(f"  - {cnt}x {reason}")

    print(f"\nPDF output folder: {pdf_dir}")
    print(f"Manifest:          {manifest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
