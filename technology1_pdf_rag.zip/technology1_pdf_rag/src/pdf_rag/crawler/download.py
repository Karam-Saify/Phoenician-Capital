from __future__ import annotations

import json
import logging
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, Optional
from urllib.parse import urlparse

import requests

from ..utils import ensure_dir, safe_filename, sha256_bytes, utc_now_iso, backoff_sleep
from .crawler import normalize_url, PdfCandidate

logger = logging.getLogger(__name__)


@dataclass
class PdfRecord:
    source_url: str
    final_url: str | None
    local_path: str | None
    downloaded_at: str
    http_status: int | None
    content_length: int | None = None
    sha256: str | None = None
    status: str = "failed"  # downloaded|skipped|failed
    reason: str | None = None
    discovered_on: str | None = None


def _is_pdf_magic(b: bytes) -> bool:
    return b.startswith(b"%PDF")


def download_pdf(
    session: requests.Session,
    url: str,
    out_dir: Path,
    candidate: Optional[PdfCandidate] = None,
    max_retries: int = 3,
    skip_if_exists: bool = True,
) -> PdfRecord:
    ensure_dir(out_dir)
    norm_url = normalize_url(url)

    # Derive a readable base name; add short hash to avoid collisions.
    path = urlparse(norm_url).path
    base_name = Path(path).name or "document.pdf"
    if not base_name.lower().endswith(".pdf"):
        base_name += ".pdf"
    base_name = safe_filename(base_name)
    short = sha256_bytes(norm_url.encode("utf-8"))[:10]
    filename = f"{Path(base_name).stem}__{short}.pdf"
    out_path = out_dir / filename

    if skip_if_exists and out_path.exists():
        return PdfRecord(
            source_url=norm_url,
            final_url=None,
            local_path=str(out_path.as_posix()),
            downloaded_at=utc_now_iso(),
            http_status=200,
            content_length=out_path.stat().st_size,
            sha256=None,
            status="skipped",
            reason="already_exists",
            discovered_on=candidate.discovered_on if candidate else None,
        )

    for attempt in range(1, max_retries + 1):
        try:
            r = session.get(norm_url, allow_redirects=True, stream=True, timeout=30)
            status = r.status_code
            final_url = str(r.url)

            if status >= 400:
                return PdfRecord(
                    source_url=norm_url,
                    final_url=final_url,
                    local_path=None,
                    downloaded_at=utc_now_iso(),
                    http_status=status,
                    status="failed",
                    reason=f"http_{status}",
                    discovered_on=candidate.discovered_on if candidate else None,
                )

            # Validate by content-type OR PDF magic bytes
            ct = (r.headers.get("Content-Type") or "").lower()
            first = r.raw.read(5, decode_content=True)  # type: ignore[attr-defined]

            is_pdf = ("application/pdf" in ct) or _is_pdf_magic(first)
            if not is_pdf:
                return PdfRecord(
                    source_url=norm_url,
                    final_url=final_url,
                    local_path=None,
                    downloaded_at=utc_now_iso(),
                    http_status=status,
                    status="failed",
                    reason=f"not_pdf_content_type={ct or 'unknown'}",
                    discovered_on=candidate.discovered_on if candidate else None,
                )

            # Write first bytes + remainder
            with out_path.open("wb") as f:
                f.write(first)
                for chunk in r.iter_content(chunk_size=1024 * 128):
                    if chunk:
                        f.write(chunk)

            size = out_path.stat().st_size
            sha = None
            try:
                # Quick sha256 of file contents (stream already wrote)
                import hashlib
                h = hashlib.sha256()
                with out_path.open("rb") as f:
                    for ch in iter(lambda: f.read(1024 * 1024), b""):
                        h.update(ch)
                sha = h.hexdigest()
            except Exception:
                sha = None

            return PdfRecord(
                source_url=norm_url,
                final_url=final_url,
                local_path=str(out_path.as_posix()),
                downloaded_at=utc_now_iso(),
                http_status=status,
                content_length=size,
                sha256=sha,
                status="downloaded",
                reason=None,
                discovered_on=candidate.discovered_on if candidate else None,
            )
        except requests.RequestException as e:
            logger.warning("download error (%s) attempt %s/%s for %s", e, attempt, max_retries, norm_url)
            backoff_sleep(attempt)

    return PdfRecord(
        source_url=norm_url,
        final_url=None,
        local_path=None,
        downloaded_at=utc_now_iso(),
        http_status=None,
        status="failed",
        reason="max_retries_exceeded",
        discovered_on=candidate.discovered_on if candidate else None,
    )


def download_all(
    pdf_candidates: Dict[str, PdfCandidate],
    out_dir: Path,
    max_pdfs: int = 50,
    rate_limit_s: float = 0.2,
) -> list[PdfRecord]:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": "Mozilla/5.0 (compatible; PDFRAGBot/1.0; +https://example.com)",
            "Accept": "application/pdf,application/octet-stream;q=0.9,*/*;q=0.8",
        }
    )

    records: list[PdfRecord] = []
    urls = list(pdf_candidates.keys())[:max_pdfs]
    for i, url in enumerate(urls, start=1):
        rec = download_pdf(session, url, out_dir, candidate=pdf_candidates.get(url))
        records.append(rec)
        if rate_limit_s:
            import time
            time.sleep(rate_limit_s)

    return records


def write_manifest(
    manifest_path: Path,
    start_url: str,
    max_depth: int,
    max_pdfs: int,
    pages_visited: int,
    pdfs_found: int,
    records: list[PdfRecord],
    crawl_failures: list[dict],
) -> dict:
    ensure_dir(manifest_path.parent)

    manifest = {
        "run": {
            "start_url": start_url,
            "max_depth": max_depth,
            "max_pdfs": max_pdfs,
            "pages_visited": pages_visited,
            "pdfs_found": pdfs_found,
            "pdfs_downloaded": sum(1 for r in records if r.status == "downloaded"),
            "pdfs_skipped": sum(1 for r in records if r.status == "skipped"),
            "download_failures": sum(1 for r in records if r.status == "failed"),
            "crawl_failures": len(crawl_failures),
            "timestamp_utc": utc_now_iso(),
        },
        "items": [asdict(r) for r in records],
        "crawl_failures": crawl_failures,
    }

    with manifest_path.open("w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)

    return manifest
