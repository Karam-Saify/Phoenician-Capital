from __future__ import annotations

import json
import logging
import mimetypes
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, Optional, Set, Tuple
from urllib.parse import urljoin, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup

from ..utils import ensure_dir, safe_filename, utc_now_iso, backoff_sleep

logger = logging.getLogger(__name__)


@dataclass
class PdfCandidate:
    url: str
    discovered_on: str


@dataclass
class CrawlResult:
    start_url: str
    pages_visited: int
    pdf_candidates: Dict[str, PdfCandidate]
    crawl_failures: list[dict]


DEFAULT_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)


def normalize_url(url: str) -> str:
    """Normalize URLs for deduplication (strip fragments, normalize host, keep query)."""
    p = urlparse(url)
    scheme = p.scheme.lower() if p.scheme else "https"
    netloc = p.netloc.lower()

    # Drop default ports
    if netloc.endswith(":80") and scheme == "http":
        netloc = netloc[:-3]
    if netloc.endswith(":443") and scheme == "https":
        netloc = netloc[:-4]

    path = re.sub(r"/{2,}", "/", p.path or "/")
    # Keep trailing slash only for root; otherwise strip for stability
    if path != "/" and path.endswith("/"):
        path = path[:-1]

    return urlunparse((scheme, netloc, path, p.params, p.query, ""))  # strip fragment


def in_scope(url: str, allowed_netloc: str) -> bool:
    p = urlparse(url)
    return (p.netloc.lower() == allowed_netloc.lower())


def looks_like_pdf_url(url: str) -> bool:
    p = urlparse(url)
    path = (p.path or "").lower()
    if path.endswith(".pdf"):
        return True
    # Some IR sites use query params like ?download=...pdf
    if ".pdf" in path:
        return True
    if ".pdf" in (p.query or "").lower():
        return True
    return False


def make_session(timeout_s: float = 20.0) -> requests.Session:
    s = requests.Session()
    s.headers.update({"User-Agent": DEFAULT_UA, "Accept": "text/html,application/pdf;q=0.9,*/*;q=0.8"})
    s.request = _wrap_request_with_timeout(s.request, timeout_s)
    return s


def _wrap_request_with_timeout(fn, timeout_s: float):
    def wrapped(method, url, **kwargs):
        if "timeout" not in kwargs:
            kwargs["timeout"] = timeout_s
        return fn(method, url, **kwargs)
    return wrapped


def fetch_html(session: requests.Session, url: str, max_retries: int = 3) -> Tuple[Optional[str], Optional[int], Optional[str]]:
    """Return (html, status, final_url)."""
    for attempt in range(1, max_retries + 1):
        try:
            r = session.get(url, allow_redirects=True)
            ct = (r.headers.get("Content-Type") or "").lower()
            if r.status_code >= 400:
                return None, r.status_code, str(r.url)
            if "text/html" not in ct and "application/xhtml" not in ct and "text/" not in ct:
                # Not HTML (maybe pdf) - treat as no html
                return None, r.status_code, str(r.url)
            return r.text, r.status_code, str(r.url)
        except requests.RequestException as e:
            logger.warning("fetch_html error (%s) attempt %s/%s", e, attempt, max_retries)
            backoff_sleep(attempt)
    return None, None, None


def extract_links(html: str, base_url: str) -> Set[str]:
    soup = BeautifulSoup(html, "html.parser")
    links: Set[str] = set()
    for a in soup.find_all("a", href=True):
        href = a.get("href") or ""
        href = href.strip()
        if not href or href.startswith("mailto:") or href.startswith("javascript:"):
            continue
        abs_url = urljoin(base_url, href)
        links.add(abs_url)
    return links


def crawl(start_url: str, max_depth: int = 2, max_pages: int = 500, rate_limit_s: float = 0.2) -> CrawlResult:
    """BFS crawl within the start_url host; discover PDF links."""
    start_norm = normalize_url(start_url)
    allowed_netloc = urlparse(start_norm).netloc

    session = make_session()

    queue: list[Tuple[str, int]] = [(start_norm, 0)]
    visited: Set[str] = set()

    pdf_candidates: Dict[str, PdfCandidate] = {}
    crawl_failures: list[dict] = []

    pages_visited = 0

    while queue and pages_visited < max_pages:
        url, depth = queue.pop(0)
        url = normalize_url(url)

        if url in visited:
            continue
        visited.add(url)

        if not in_scope(url, allowed_netloc):
            continue
        if depth > max_depth:
            continue

        html, status, final_url = fetch_html(session, url)
        pages_visited += 1

        if html is None:
            # Could still be a PDF URL reached via navigation - record as failure only for HTML pages
            if status is None:
                crawl_failures.append({"url": url, "reason": "request_failed"})
            else:
                crawl_failures.append({"url": url, "reason": f"http_{status}"})
            continue

        if rate_limit_s:
            import time
            time.sleep(rate_limit_s)

        links = extract_links(html, final_url or url)

        for link in links:
            link_norm = normalize_url(link)
            if not in_scope(link_norm, allowed_netloc):
                continue

            if looks_like_pdf_url(link_norm):
                if link_norm not in pdf_candidates:
                    pdf_candidates[link_norm] = PdfCandidate(url=link_norm, discovered_on=url)
                continue

            # Skip common non-HTML assets
            lower_path = urlparse(link_norm).path.lower()
            if any(lower_path.endswith(ext) for ext in [".jpg", ".jpeg", ".png", ".gif", ".svg", ".css", ".js", ".zip"]):
                continue

            if link_norm not in visited and depth + 1 <= max_depth:
                queue.append((link_norm, depth + 1))

    return CrawlResult(
        start_url=start_norm,
        pages_visited=pages_visited,
        pdf_candidates=pdf_candidates,
        crawl_failures=crawl_failures,
    )
