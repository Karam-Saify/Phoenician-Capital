from __future__ import annotations

import hashlib
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def safe_filename(name: str, max_len: int = 180) -> str:
    # Keep it filesystem-safe and readable
    name = name.strip().replace(" ", "_")
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name)
    name = re.sub(r"_+", "_", name).strip("_")
    if not name:
        name = "file"
    if len(name) > max_len:
        base, dot, ext = name.partition(".")
        name = base[: max_len - (len(ext) + 1)] + (("." + ext) if dot else "")
    return name


def backoff_sleep(attempt: int, base: float = 0.5, cap: float = 8.0) -> None:
    # Exponential backoff with cap
    delay = min(cap, base * (2 ** max(0, attempt - 1)))
    time.sleep(delay)


def simple_tokenize(text: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9]+", text.lower())
